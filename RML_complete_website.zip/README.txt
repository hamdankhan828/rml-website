RML COMPLETE WEBSITE STARTER
=============================

Files:
- index.html: responsive public website starter for RML.
- Includes services, test prices placeholder, packages, secure report portal placeholder, home collection, contact and WhatsApp.
- Pricing intentionally left blank pending RML's updated price list.
- Patient report form is a visual placeholder only; it does NOT authenticate users or retrieve reports.

PUBLISH FREE (GitHub Pages)
1. Sign in/create a GitHub account.
2. Create a repository named rml-website.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Choose deploy from the main branch and root folder.
6. GitHub provides a free URL like https://YOUR-USERNAME.github.io/rml-website/

Google visibility:
- After publishing, register the URL with Google Search Console and request indexing.
- Google indexing is not instant or guaranteed.
- A Google Business Profile should also be maintained separately with matching business name, address, phone, hours and category.

Patient privacy/security:
- Do not upload patient PDFs into a public repository or public website folder.
- Real report access requires a secure backend or HCloud-approved patient portal/API, authentication/OTP, private storage, access logging, backups and HTTPS.
- Confirm HCloud integration options and charges with HCloud support before handling real reports online.

Before public launch:
- Confirm phone/address, opening hours, test availability, prices, package inclusions and any claims.
- Add the official logo if available.
- Replace the report placeholder only after the secure integration is working.
